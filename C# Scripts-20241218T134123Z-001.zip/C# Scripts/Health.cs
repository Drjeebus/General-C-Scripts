﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
    Developer Name:
                Chris Foster
    Contribution: 
                Chris Foster
    Feature:
                Generic destroy object with collides with "Ball"
    Start & End dates 
                Dec 1st, 2018
    References: 
                Unity Online Documentation
    Links: 
                Origional Design
//*/

//Setting NPC Health, Taking Damage, and Destroy on "Death"
public class Health : MonoBehaviour
{

    void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Bullet")
        {
            Destroy(gameObject);
        }
    }

}