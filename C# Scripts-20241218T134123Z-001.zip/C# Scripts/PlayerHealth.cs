﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/*
//    Developer Name:
            Christopher Foster
//    Contribution:
            Chris Foster
//    Feature 
            Health System for player characters
//    Start & End dates 
            Dec 3rd, 2018
//    References: 
            My SCRAPS scripts
//    Links: 
            Origional Design
//*/

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth;
    public int currentHealth;
    public Text curHealth;
    public GameObject DeathCanvas;
    float timer = 0;

    //Enemy attack damage
    [Header("Enemy Attack Damage")]
    public int chargingEnemyDamage;
    public int shooterEnemyDamage;
    public int turretDamage;
    public int mechBossDamage;
    private AudioSource playerHit;

    private void Awake()
    {
        playerHit = GetComponent<AudioSource>();
    }

    void Start()
    {
        currentHealth = maxHealth;
        UpdateGUI();
    }

    void Update()
    {
        UpdateGUI();
    }
    
    void UpdateGUI()
    {
        curHealth.text = currentHealth.ToString();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy") //Applies damage for charging Enemies
        {
            ApplyDamage(chargingEnemyDamage);
            playerHit.Play();

            if (currentHealth <= 0)
            {
                curHealth.text = "0";
                gameObject.SetActive(false); //Sets the gameObject to inactive
                //Destroy(gameObject);
                Instantiate(DeathCanvas);
            }
        }
        if (other.tag ==  "Bullet")
        {
            ApplyDamage(shooterEnemyDamage); //Applies damage for shooting Enemies
            playerHit.Play();

            if (currentHealth <= 0)
            {
                curHealth.text = "0";
                gameObject.SetActive(false); //Sets the gameObject to inactive
                //Destroy(gameObject);
                Instantiate(DeathCanvas);
            }
        }
        /*if (other.tag == "Bullet")
        {
            ApplyDamage(1);

            if (currentHealth <= 0)
            {
                Destroy(gameObject);
                Instantiate(DeathCanvas);
            }
        }*/
    }

    public void OnHealthPickup(int amount)
    {
        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        UpdateGUI();
    }

    public void ApplyDamage(int amount)
    {
        currentHealth -= amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        playerHit.Play();

        if (currentHealth <= 0)
        {
            currentHealth = 0;
            gameObject.SetActive(false); //Sets the gameObject to inactive
            //Destroy(gameObject);
            Instantiate(DeathCanvas);
        }
    }
}
