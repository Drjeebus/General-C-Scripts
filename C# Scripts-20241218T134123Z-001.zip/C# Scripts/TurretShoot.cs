﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretShoot : MonoBehaviour
{
    public Transform player;
    public GameObject Missile;
    public float fireTimer;
    private bool shotReady;
    private bool targetLocked;

    void Start()
    {
        shotReady = true;
    }

    void Update()
    {
        if (Vector3.Distance(player.position, this.transform.position) < 20)
        {
            targetLocked = true;
        }

        if (targetLocked)
        {
            if (shotReady)
            {
                Shoot();
            }
        }
    }
    void Shoot()
    {
        Instantiate(Missile, transform.position + (transform.forward * 4), transform.rotation);
        shotReady = false;
        StartCoroutine(FireRate());
    }

    IEnumerator FireRate()
    {
        yield return new WaitForSeconds(fireTimer);
        shotReady = true;
    }
}
