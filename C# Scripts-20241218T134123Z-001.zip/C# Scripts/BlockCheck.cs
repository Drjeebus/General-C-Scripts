﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockCheck : MonoBehaviour
{
    //public GameObject destroy;

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Interactible")
        {
            Destroy(this.gameObject);
        }

    }
}
