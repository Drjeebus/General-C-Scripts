﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public void OnTriggerEnter(Collider col)
    {
        var Plasma = new List<int>();

        if (col.tag == "Player")

            Plasma.Add(1);
        Destroy(GameObject.FindWithTag("Plasma"));
        Debug.Log(Plasma.Count);
        
    }
}
