﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnSpew : MonoBehaviour
{
    public GameObject sewerSpew;

    public void Spawn()
    {
        Instantiate(sewerSpew, transform.position + transform.up * 0, transform.rotation);
    }
}
