﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chandelier : MonoBehaviour
{
    public float fallTimer;
    public float resetTimer;
    public Vector3 posA;
    public Vector3 posB;

    private bool Falling;
    
    void Start()
    {
        Falling = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            if(!Falling)
            {
                Falling = true;
                StartCoroutine(Movement());
            }
        }
    }

    IEnumerator Movement()
    {
        yield return new WaitForSeconds(fallTimer);
        float startTime = Time.time;
        while (Time.time - startTime <= 1)
        { 
            transform.position = Vector3.Lerp(posA, posB, Time.time - startTime);
            yield return 1; 
        }

        yield return new WaitForSeconds(resetTimer);
        transform.position = Vector3.Lerp(posB, posA, Time.time - startTime);
        Falling = false;
    }
}

