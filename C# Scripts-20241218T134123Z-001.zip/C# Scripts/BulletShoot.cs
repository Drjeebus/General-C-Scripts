﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletShoot : MonoBehaviour
{
    public GameObject Bullet;
    private AudioSource shootSound;

    private void Awake()
    {
        shootSound = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            Instantiate(Bullet, transform.position + (transform.forward * 2), transform.rotation);
            shootSound.Play();
        }
    }
}
