﻿using UnityEngine;
using System.Collections;
using UnityEngine.AI;
using UnityEditor;
using System;

public class Boss_00 : FSGDN.StateMachine.MachineBehaviour
{
    [SerializeField] NavPoint[] myNavPoints;
    int navIndex = 0;
    public Transform player;
    public GameObject Missile;

    public override void AddStates()
    {
        AddState<PatrolState>();
        AddState<IdleState>();

        SetInitialState<PatrolState>();
    }

    public void pickNextNavPoint()
    {
        ++navIndex;
        if (navIndex >= myNavPoints.Length)
            navIndex = 0;
    }

    public void FindDestination()
    {
        GetComponent<NavMeshAgent>().SetDestination(myNavPoints[navIndex].transform.position);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<NavPoint>())
            ChangeState<IdleState>();
    }

    public void pewPew()
    {
        if (Vector3.Distance(player.position, this.transform.position) < 20)
        {
            transform.LookAt(player);
            Instantiate(Missile, transform.position + (transform.forward * 4), transform.rotation);
        }
    }


    public class NavAgentState : FSGDN.StateMachine.State
    {
        protected Boss_00 NavAgentStateMachine()
        {
            return ((Boss_00)machine);
        }
    }

    public class PatrolState : NavAgentState
    {
        float timer = 0;

        public override void Enter()
        {
            base.Enter();
            float timer = 0;
            NavAgentStateMachine().FindDestination();
        }

    }

    public class IdleState : NavAgentState
    {
        float timer = 0;

        public override void Enter()
        {
            base.Enter();
            timer = 0;
        }
        
        public override void Execute()
        {
            timer += Time.deltaTime;
            if (timer >= 2.0f)
            {
                NavAgentStateMachine().pewPew();
                machine.ChangeState<PatrolState>();
                NavAgentStateMachine().pickNextNavPoint();
            }
        }
    }
}
