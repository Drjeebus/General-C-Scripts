﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager_PanelInstructions : MonoBehaviour
{
    public GameObject panelInstructions;
    private GameManager_Master gameManagerMaster;

    void OnEnable()
    {
        SetInitialRefrences();
        gameManagerMaster.GameOverEvent += TurnOffPanelInstructions;
    }

    void OnDisable()
    {
        gameManagerMaster.GameOverEvent -= TurnOffPanelInstructions;
    }

    void SetInitialRefrences()
    {
        gameManagerMaster = GetComponent<GameManager_Master>();
    }

    void TurnOffPanelInstructions()
    {
        if(panelInstructions != null)
        {
            panelInstructions.SetActive(false);
        }
    }
}
