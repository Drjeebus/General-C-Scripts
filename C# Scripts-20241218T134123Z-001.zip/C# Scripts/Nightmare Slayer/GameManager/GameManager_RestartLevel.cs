﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager_RestartLevel : MonoBehaviour
{
    private GameManager_Master gameManagerMaster;

    void OnEnable()
    {
        SetInitialRefrences();
        gameManagerMaster.RestartLevelEvent += RestartLevel;
    }

    void OnDisable()
    {
        gameManagerMaster.RestartLevelEvent -= RestartLevel;
    }

    void SetInitialRefrences()
    {
        gameManagerMaster = GetComponent<GameManager_Master>();
    }

    void RestartLevel()
    {
        Application.LoadLevel(Application.loadedLevel);
    }
}
