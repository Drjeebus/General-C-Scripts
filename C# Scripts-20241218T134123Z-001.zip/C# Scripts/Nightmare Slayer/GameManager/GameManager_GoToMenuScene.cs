﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager_GoToMenuScene : MonoBehaviour
{
    private GameManager_Master gameManagerMaster;
    
    void OnEnable()
    {
        SetInitialRefrences();
        gameManagerMaster.GoToMenuSceneEvent += GoToMenuScene;
    }

    void OnDisable()
    {
        gameManagerMaster.GoToMenuSceneEvent -= GoToMenuScene;
    }

    void SetInitialRefrences()
    {
        gameManagerMaster = GetComponent<GameManager_Master>();
    }

    void GoToMenuScene()
    {
        Application.LoadLevel(0);
    }
}
