﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Melee_Strike : MonoBehaviour
{
    private Melee_Master meleeMaster;
    private float nextSwingTime;
    public int damage = 25;

    void Start()
    {
        SetInitialRefrences();
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject != GameManager_Refrences._player && meleeMaster.isInUse && Time.time > nextSwingTime)
        {
            nextSwingTime = Time.time + meleeMaster.swingRate;
            collision.transform.SendMessage("ProcessDamage", damage, SendMessageOptions.DontRequireReceiver);
            meleeMaster.CallEventHit(collision, collision.transform);
        }
    }

   void SetInitialRefrences()
    {
        meleeMaster = GetComponent<Melee_Master>();
    }
}
