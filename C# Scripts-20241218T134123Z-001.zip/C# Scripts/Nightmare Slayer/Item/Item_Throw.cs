﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_Throw : MonoBehaviour
{
    private Item_Master itemMaster;
    private Transform myTransform;
    private Vector3 throwDirection;
    private Rigidbody myRigidbody;

    public bool canBeThrown;
    public string throwButtonName;
    public float throwForce;

    void Start()
    {
        SetInitialRefrences();
    }

    void Update()
    {
        CheckForThrowInput();
    }

    void SetInitialRefrences()
    {
        itemMaster = GetComponent<Item_Master>();
        myTransform = transform;
        myRigidbody = GetComponent<Rigidbody>();
    }

    void CheckForThrowInput()
    {
        if(throwButtonName != null)
        {
            if(Input.GetButtonDown(throwButtonName) && Time.timeScale > 0 && canBeThrown && myTransform.root.CompareTag(GameManager_Refrences._playerTag))
            {
                CarryOutThrowActions();
            }
        }
    }

    void CarryOutThrowActions()
    {
        throwDirection = myTransform.parent.forward;
        myTransform.parent = null;
        itemMaster.CallEventObjectThrow();
        HurlItem();
    }

    void HurlItem()
    {
        myRigidbody.AddForce(throwDirection * throwForce, ForceMode.Impulse);
    }
}
