﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_Sounds : MonoBehaviour
{
    private Item_Master itemmaster;
    public float defaultVolume;
    public AudioClip throwSound;

    void OnEnable()
    {
        SetInitialRefrences();
        itemmaster.EventObjectThrow += PlayThrowSound;
    }

    void OnDisable()
    {
        itemmaster.EventObjectThrow -= PlayThrowSound;
    }

    void SetInitialRefrences()
    {
        itemmaster = GetComponent<Item_Master>();
    }

    void PlayThrowSound()
    {
        if(throwSound != null)
        {
            AudioSource.PlayClipAtPoint(throwSound, transform.position, defaultVolume);
        }
    }
}
