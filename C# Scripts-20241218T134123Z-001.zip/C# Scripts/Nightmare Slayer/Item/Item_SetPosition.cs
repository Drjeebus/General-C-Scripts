﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_SetPosition : MonoBehaviour
{
    private Item_Master itemMaster;
    public Vector3 itemLocalPosition;

    void OnEnable()
    {
        SetInitialRefrences();
        itemMaster.EventObjectPickup += SetPositionOnPlayer;
    }

    void onDisable()
    {
        itemMaster.EventObjectPickup -= SetPositionOnPlayer;
    }

    void Start()
    {
        SetPositionOnPlayer();
    }

    void SetInitialRefrences()
    {
        itemMaster = GetComponent<Item_Master>();
        SetPositionOnPlayer();
    }

    void SetPositionOnPlayer()
    {
        if(transform.root.CompareTag(GameManager_Refrences._playerTag))
        {
            transform.localPosition = itemLocalPosition;
        }
    }
}

