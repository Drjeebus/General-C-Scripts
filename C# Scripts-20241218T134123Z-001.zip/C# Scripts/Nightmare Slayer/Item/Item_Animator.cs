﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_Animator : MonoBehaviour
{
    private Item_Master itemMaster;
    public Item_Animator myAnimator;

    void OnEnable()
    {
        SetInitialRefrences();
        itemMaster.EventObjectThrow += DisableMyAnimator;
        itemMaster.EventObjectPickup += EnabledMyAnimator;
    }

    void OnDisabled()
    {
        itemMaster.EventObjectThrow -= DisableMyAnimator;
        itemMaster.EventObjectPickup -= EnabledMyAnimator;
    }

    void SetInitialRefrences()
    {
        itemMaster = GetComponent<Item_Master>();
    }

    void EnabledMyAnimator()
    {
        if(myAnimator != null)
        {
            myAnimator.enabled = true;
        }
    }

    void DisableMyAnimator()
    {
        if (myAnimator != null)
        {
            myAnimator.enabled = false;
        }
    }
}
