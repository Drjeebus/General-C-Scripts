﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_HealthPickup : MonoBehaviour
{
    private Item_Master itemMaster;
    private GameObject playerGo;
    public int healAmount;
    public bool isTriggerPickup;

    void OnEnable()
    {
        SetInitialRefrences();
        itemMaster.EventObjectPickup += TakeHealth;
    }

    void OnDisable()
    {
        itemMaster.EventObjectPickup -= TakeHealth;
    }

    void Start()
    {
        SetInitialRefrences();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(GameManager_Refrences._playerTag) && isTriggerPickup)
        {
            TakeHealth();
        }
    }

    void SetInitialRefrences()
    {
        itemMaster = GetComponent<Item_Master>();
        playerGo = GameManager_Refrences._player;

        if (isTriggerPickup)
        {
            if (GetComponent<Collider>() != null)
            {
                GetComponent<Collider>().isTrigger = true;
            }

            if (GetComponent<Rigidbody>() != null)
            {
                GetComponent<Rigidbody>().isKinematic = true;
            }
        }
    }

    void TakeHealth()
    {
        playerGo.GetComponent<Player_Master>().CallEventPlayerHealthIncrease(healAmount);
        Destroy(gameObject);
    }
}
