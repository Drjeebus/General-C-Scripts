﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_CanvasHurt : MonoBehaviour
{
    public GameObject hurtCanvas;
    private Player_Master player_Master;
    private float secondsTillHide = 2;

    void OnEnable()
    {
        SetInitialRefrences();
        player_Master.EventPlayerHealthDeduction += TurnOnHurtEffect;
    }

    void OnDisable()
    {
        player_Master.EventPlayerHealthDeduction -= TurnOnHurtEffect;
    }

    void SetInitialRefrences()
    {
        player_Master = GetComponent<Player_Master>();
    }

    void TurnOnHurtEffect(int dummy)
    {
        if(hurtCanvas != null)
        {
            StopAllCoroutines();
            hurtCanvas.SetActive(true);
            StartCoroutine(ResetHurtCanvas());
        }
    }

    IEnumerator ResetHurtCanvas()
    {
        yield return new WaitForSeconds(secondsTillHide);
        hurtCanvas.SetActive(false);
    }
}
