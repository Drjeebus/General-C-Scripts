﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Health : MonoBehaviour
{
    private Enemy_Master enemyMaster;
    public int enemyHealth = 100;
    //heal
    public float healthLow = 25;

    void OnEnable()
    {
        SetInitialRefrences();
        enemyMaster.EventEnemyDeductHealth += DeductHealth;
        //heal
        enemyMaster.EventEnemyIncreaseHealth += IncreaseHealth;
    }
    
    void OnDisable()
    {
        enemyMaster.EventEnemyDeductHealth -= DeductHealth;
        //heal
        enemyMaster.EventEnemyIncreaseHealth -= IncreaseHealth;
    }

    void SetInitialRefrences()
    {
        enemyMaster = GetComponent<Enemy_Master>();
    }

    void DeductHealth(int healthChange)
    {
        enemyHealth -= healthChange;
        if(enemyHealth <= 0)
        {
            enemyHealth = 0;
            enemyMaster.CallEventEnemyDie();
            Destroy(gameObject, Random.Range(4, 6));
        }
        //heal
        CheckHealthFraction();
    }
    //heal
    void CheckHealthFraction()
    {
        if(enemyHealth <= healthLow && enemyHealth > 0)
        {
            enemyMaster.CallEventEnemyHealthLow();
        }
        else if(enemyHealth > healthLow)
        {
            enemyMaster.CallEventEnemyHealthRecovered();
        }
    }
    //heal
    void IncreaseHealth(int healthChange)
    {
        enemyHealth += healthChange;
        if(enemyHealth > 100)
        {
            enemyHealth = 100;
        }

        CheckHealthFraction();
    }
}
