﻿using System.Collections;
using UnityEngine;

public class HealthPack : MonoBehaviour
{
    public int addHealth = 0;


   void OnTriggerEnter(Collider other)
    {
        PlayerHealth player = other.GetComponent<PlayerHealth>();

        if (player != null)
        {
            player.OnHealthPickup(addHealth);
            gameObject.SetActive(false);
        }
    }
}
