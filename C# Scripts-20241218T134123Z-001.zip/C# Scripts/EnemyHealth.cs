﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
//    Developer Name:
            Christopher Foster
//    Contribution:
            Chris Foster
//    Feature 
            Health System for player characters
//    Start & End dates 
            Dec 3rd, 2018
//    References: 
            My SCRAPS scripts
//    Links: 
            Origional Design
//*/

public class EnemyHealth : MonoBehaviour
{
    public int maxHealth = 0;
    public int currentHealth;
    //public GameObject WinCanvas;
    //public AudioSource enemyDeath;
    //public AudioSource enemyHit;
    public AudioSource enemyAudio1;
    //public AudioSource enemyAudio2;
    public AudioClip enemyDeath;
    public AudioClip enemyHit;
    public GameObject enemyDeathSoundHolder;



    void Start()
    {
        currentHealth = maxHealth;
        enemyAudio1 = GetComponent<AudioSource>();
        //enemyAudio2 = GetComponent<AudioSource>();
        AudioSource[] enemyAudio = GetComponents<AudioSource>();
        //enemyHit = enemyAudio[0];
        //enemyDeath = enemyAudio[1];
        

    }

    void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Bullet")
        {
            currentHealth--;
            gameObject.GetComponent<AudioSource>().PlayOneShot(enemyHit);

            if (currentHealth <= 0)
            {
                enemyDeathSoundHolder.GetComponent<AudioSource>().PlayOneShot(enemyDeath);
                gameObject.SetActive(false);
                //Destroy(gameObject);
                //Instantiate(WinCanvas);

            }
        }
    }

   /* public void ApplyDamage(int amount)
    {
        currentHealth -= amount;
        enemyAudio.PlayOneShot(enemyHit, 1);

        if (currentHealth <= 0)
        {
            
            currentHealth = 0;
            enemyAudio.PlayOneShot(enemyDeath, 1);
            Destroy(gameObject);
        }
    }*/
}
