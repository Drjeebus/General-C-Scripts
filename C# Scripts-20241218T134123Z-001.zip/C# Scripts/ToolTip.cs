﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToolTip : MonoBehaviour
{
    public bool onTrigger;

    void OnTriggerStay(Collider other)
    {
        onTrigger = true;
    }

    void OnTriggerExit(Collider other)
    {
        onTrigger = false;
    }
    void OnGUI()
    {
        if (onTrigger)
        {
            GUI.Box(new Rect(215/*MoveRight*/, 525/*MoveDown*/, 320/*StrechDown*/, 35/*StrechLeft*/), "I need a key. I bet a Skeleton has it!");
            GUI.Box(new Rect(220, 530, 310, 25), "");
        }
    }
}

