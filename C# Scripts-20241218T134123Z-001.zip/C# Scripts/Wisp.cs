﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wisp : MonoBehaviour
{
    public float speed;

    public GameObject Target;
    public float aggroRadius;


    void Start()
    {
        StartCoroutine(Destroy());
    }

    void Update()
    {
        if (Target == null)
        {
            SearchForTarget();
        }
        if (Target != null)
        {
            FollowTarget();
        }
    }

    void SearchForTarget()
    {
        Vector3 center = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
        Collider[] hitColliders = Physics.OverlapSphere(center, aggroRadius);
        int i = 0;
        while (i < hitColliders.Length)
        {
            if (hitColliders[i].transform.tag == "Collectible")
            {
                //can do anything in here like different attacks/abilities, cleave
                Target = hitColliders[i].transform.gameObject;
            }
            i++;
        }
    }

    void FollowTarget()
    {
        //Face towards Target always
        Vector3 targetPosition = Target.transform.position;
        targetPosition.y = transform.position.y;
        transform.LookAt(targetPosition);

        float distance = Vector3.Distance(Target.transform.position, this.transform.position);
        if (distance > 1)
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }
        if (distance <= 1)
        {
            Destroy(this.gameObject);
        }
    }

    IEnumerator Destroy()
    {
        yield return new WaitForSeconds(3);
        Destroy(this.gameObject);
    }
}
