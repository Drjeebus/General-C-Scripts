﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeWisp : MonoBehaviour
{
    public GameObject wisp;
    public GameObject Target;
    public float aggroRadius;

    private bool treasure;

    void Start()
    {
        treasure = true;
    }

    void Update()
    {
        if (Target == null)
        {
            SearchForTarget();
        }
        if (Target != null)
        {
            if (treasure)
            {
                StartCoroutine(Wisp());
            }
        }
    }

    void SearchForTarget()
    {
        Vector3 center = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
        Collider[] hitColliders = Physics.OverlapSphere(center, aggroRadius);
        int i = 0;
        while (i < hitColliders.Length)
        {
            if (hitColliders[i].transform.tag == "Collectible")
            {
                //can do anything in here like different attacks/abilities, cleave
                Target = hitColliders[i].transform.gameObject;
            }
            i++;
        }
    }

    IEnumerator Wisp()
    {
        treasure = false;
        Instantiate(wisp, transform.position + (transform.forward * 0), transform.rotation);
        yield return new WaitForSeconds(1);
        treasure = true;
    }
}
