﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Shoot : MonoBehaviour
{
    public Transform player;
    public GameObject Bullet;
    public float fireTimer;
    private bool shotReady;
    private bool targetLocked;

    void Start()
    {
        shotReady = true;
    }

    void Update()
    {
        if (Vector3.Distance(player.position, this.transform.position) < 20)
        {
            targetLocked = true;
           
        }

        if (targetLocked)
        {
            if (shotReady)
            {
                Shoot();
            }
        }
    }
    void Shoot()
    {
        Instantiate(Bullet, transform.position + (transform.forward * 4), transform.rotation);
        shotReady = false;
        StartCoroutine(FireRate());
    }

    IEnumerator FireRate()
    {
        yield return new WaitForSeconds(fireTimer);
        shotReady = true;
    }
}
