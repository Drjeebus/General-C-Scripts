﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostDooorTrigger : MonoBehaviour
{
    public GameObject destroy;

    void OnTriggerEnter(Collider other)
    {
            if (other.tag == "Player")
            {
                gameObject.GetComponent<AudioSource>().Play();
                Destroy(destroy.gameObject);
            }
        
    }
}
