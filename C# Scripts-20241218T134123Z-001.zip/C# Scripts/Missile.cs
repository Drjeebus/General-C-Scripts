﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile : MonoBehaviour
{
    public Transform target;
    public float speed;
    public int addDamage = 0;
    float timer = 0;

    void Update()
    {
        Vector3 direction = target.position - this.transform.position;
        transform.Translate(Vector3.forward * Time.deltaTime * speed);

        this.transform.rotation = Quaternion.Slerp(this.transform.rotation,
                        Quaternion.LookRotation(direction), .0f);

        timer += Time.deltaTime;
        if (timer >= 5.0f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        PlayerHealth player = other.GetComponent<PlayerHealth>();

        if (player != null)
        {
            player.ApplyDamage(addDamage);
            Destroy(gameObject);
        }
    }
}
