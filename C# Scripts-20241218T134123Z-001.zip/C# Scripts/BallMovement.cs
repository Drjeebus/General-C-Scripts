﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
    Developer Name:
                Chris Foster
    Contribution: 
                Chris Foster
    Feature:
                Projectile Movement/Destruction 
    Start & End dates 
                Dec 4th, 2018
    References: 
                None
    Links: 
                Origional Design
//*/

public class BallMovement : MonoBehaviour
{

    public float movementSpeed;
    float timer = 0;

    void Update()
    {
        transform.Translate(Vector3.forward * Time.deltaTime * movementSpeed);
        timer += Time.deltaTime;
        if (timer >= 1.5f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Enemy" || col.tag == "Player" || col.tag == "Turret" || col.tag == "Barrier")
        {
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.collider.tag == "Barrier")
        {
            Destroy(gameObject);
        }
    }
}

   
    

