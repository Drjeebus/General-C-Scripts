﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyShoot : MonoBehaviour
{
    public Rigidbody flyBullet;
    public float velocity = 10.0f;
    public float fireTimer;
    private bool shotReady;

    void Start()
    {
        shotReady = true;
    }

    // Update is called once per frame
    void Update()
    {
        
            if (shotReady)
            {
                Shoot();
            }
        
    }

    void Shoot()
    {
        Rigidbody newBullet = Instantiate(flyBullet, transform.position, transform.rotation) as Rigidbody;
        newBullet.AddForce(transform.forward * velocity, ForceMode.VelocityChange);
        shotReady = false;
        StartCoroutine(FireRate());
    }

    IEnumerator FireRate()
    {
        yield return new WaitForSeconds(fireTimer);
        shotReady = true;
    }
}
