﻿using UnityEngine;
using System.Collections;

public class EnemyMovement : MonoBehaviour
{
    public Transform player;
    public float speed = 0f;

    void Update()
    {

        if (Vector3.Distance(player.position, this.transform.position) < 20) 
        {
           
            Vector3 direction = player.position - this.transform.position;
            
            this.transform.rotation = Quaternion.Slerp(this.transform.rotation,
                            Quaternion.LookRotation(direction), 1f);

            if (direction.magnitude > 1.5)
            {

                transform.Translate(Vector3.forward * Time.deltaTime * speed);
            }

        }
    }
}