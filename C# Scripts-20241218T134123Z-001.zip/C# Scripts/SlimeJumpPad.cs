﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeJumpPad : MonoBehaviour
{
    public GameObject slimeSpew;
    public float restTimer;

    private bool isActive;

    void Start()
    {
        isActive = true;
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            if (isActive)
            {
                isActive = false;
                Instantiate(slimeSpew, transform.position + transform.up * 0, transform.rotation);
                StartCoroutine(Reset());
            }
        }
    }

    IEnumerator Reset()
    {
        yield return new WaitForSeconds(restTimer);
        isActive = true;
    }
}
