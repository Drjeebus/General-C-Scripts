﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TornadoSpawn : MonoBehaviour
{
    private bool isActive;
    public GameObject tornado;
    
    public void FixedUpdate()
    {
        if (!isActive)
        {
            int rand = Random.Range(0, 4);

            if (rand == 0)
            {
                isActive = true;
                StartCoroutine(Tornado());
            }
            if (rand == 1)
            {
                isActive = true;
                StartCoroutine(NoTornado());
            }
            if (rand == 2)
            {
                isActive = true;
                StartCoroutine(Tornado());
            }
            if (rand == 3)
            {
                isActive = true;
                StartCoroutine(NoTornado());
            }
        }
    }

    IEnumerator Tornado()
    {
        Instantiate(tornado, transform.position + (transform.forward * 1), transform.rotation);
        yield return new WaitForSeconds(2);
        isActive = false;
    }

    IEnumerator NoTornado()
    {
        yield return new WaitForSeconds(1);
        isActive = false;
    }
}
