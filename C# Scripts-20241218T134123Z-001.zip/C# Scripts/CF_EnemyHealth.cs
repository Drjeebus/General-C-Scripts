﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
//    Developer Name:
            Christopher Foster
//    Contribution:
            Chris Foster
//    Feature 
            Health System for player characters
//    Start & End dates 
            Dec 3rd, 2018
//    References: 
            My SCRAPS scripts
//    Links: 
            Origional Design
//*/

public class CF_EnemyHealth : MonoBehaviour
{
    public int maxHealth = 0;
    public int currentHealth;


    void Start()
    {
        currentHealth = maxHealth;
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Bullet")
        {
            currentHealth--;

            if (currentHealth <= 0)
            {
                Destroy(gameObject);
            }
        }
    }

    public void ApplyDamage(int amount)
    {
        currentHealth -= amount;
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            Destroy(gameObject);
        }
    }
}
