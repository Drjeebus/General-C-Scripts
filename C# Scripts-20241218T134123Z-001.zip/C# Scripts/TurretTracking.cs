﻿using UnityEngine;
using System.Collections;
using UnityEngine.AI;
using UnityEditor;
using System;

public class TurretTracking : MonoBehaviour
{
    float timer = 0;
    public Transform player;

    public void Update()
    {
        if (Vector3.Distance(player.position, this.transform.position) < 20)
        {
            transform.LookAt(player);
        }
    }
}
