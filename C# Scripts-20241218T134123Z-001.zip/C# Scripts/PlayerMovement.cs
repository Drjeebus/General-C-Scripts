﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 6f;
    Vector3 movement;
    Rigidbody playerRigidbody;
    int floorMask;
    float camRayLength = 100f;
    public GameObject Bullet;
    private AudioSource Audio;

    //public bool isMoving;
    private bool damageReady;
   // public float moveTimer = 2.0f;
    private PlayerHealth health;
    //public int standDamage;
    public Material normal;

    private int plasmaCount; //Plasma collectible counter value
    public Text plasmaText; //Text component in HUD
    

    private void Start()
    {
        damageReady = true;
        plasmaCount = 0;
        SetPlasmaCountText();
        
    }


    void Awake()
    {
        floorMask = LayerMask.GetMask ("Floor");
        playerRigidbody = GetComponent<Rigidbody> ();
        health = GetComponent<PlayerHealth>();
    }

    void Update()
    {
        /*if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            Instantiate(Bullet, transform.position + (transform.forward * 2), transform.rotation);
            //Audio.Play();
           
        }*/
        
         
    }
	
    void FixedUpdate()
    {
        float h = Input.GetAxisRaw ("Horizontal");
        float v = Input.GetAxisRaw ("Vertical");

        Move (h, v);
        Turning ();
        /*NoMoveDamage();
        
        if (h != 0 || v != 0)
        {
            isMoving = true;
        }
        else
        {
            isMoving = false;
        }*/

    }

    void Move (float h, float v)
    {
        movement.Set(h, 0f, v);
        movement = movement.normalized * speed * Time.deltaTime;

        playerRigidbody.MovePosition (transform.position + movement);
        
    }

    void Turning()
    {
        Ray camRay = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit floorHit;

        if (Physics.Raycast(camRay, out floorHit, camRayLength, floorMask))
        {
            Vector3 playerToMouse = floorHit.point - transform.position;
            playerToMouse.y = 0f;

            Quaternion newRotation = Quaternion.LookRotation(playerToMouse);
            playerRigidbody.MoveRotation(newRotation);
            
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            //other.gameObject.SetActive(false);
            Destroy(other.gameObject);
            
        }
        if (other.gameObject.tag == "Plasma")
            {
                plasmaCount = plasmaCount + 1;
                SetPlasmaCountText();
            Destroy(other.gameObject);
                
            }
    }
    
    //Checks if the player is moving or not. If not moving the player will be dealt damage for standing still.
    /*void NoMoveDamage()
    {
        moveTimer -= Time.deltaTime;

        if (isMoving == true)
        {
            moveTimer = 1.0f;
            GetComponent<SkinnedMeshRenderer>().material = normal;
        }
        if (isMoving == false)
        {
            if (moveTimer <= 0.0f)
            {
                health.ApplyDamage(standDamage);
                damageReady = false;
                GetComponent<SkinnedMeshRenderer>().material.color = Color.red;

            }
            if (damageReady == false)
            {
                
                moveTimer = 1.0f;
                damageReady = true;
                
            } 
        }
    }*/

    void SetPlasmaCountText()
    {
        plasmaText.text = "Plasma " + plasmaCount.ToString();
    }

    
}
