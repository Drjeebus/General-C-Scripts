﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompSimple : MonoBehaviour
{
    public bool isAttack;
    public bool isFollow;

    private bool canAttack;
    public float speed;

    public GameObject projectile;

    public float fireRate;

    public GameObject Target;
    public float aggroRadius;

    public bool returnPlayer;
    public float returnToDistance;

    [Header("Player")]
    public Transform player;
    public float playerTrackingDistance;
    public float distance;

    public void Start()
    {
        canAttack = true;
    }

    public void Update()
    {
        if (isAttack)
        {
            StartCoroutine(Attack());
        }

        float distanceFromPlayer = Vector3.Distance(player.transform.position, this.transform.position);
        if (distanceFromPlayer > returnToDistance && !returnPlayer)
        {
            Target = null;
            returnPlayer = true;
        }
        if (Target == null)
        {
            if (returnPlayer)
            {
                ReturnPlayer();
            }
            else
                SearchForTarget();
            FollowPlayer();
        }
        if (Target != null)
        {
            FollowTarget();
        }
    }

    IEnumerator Attack()
    {
        if(isAttack)
        {
            if (canAttack)
            {
                canAttack = false;
                isAttack = false;
                Instantiate(projectile, transform.position + (transform.forward * 1), transform.rotation);
                yield return new WaitForSeconds(fireRate);
                canAttack = true;
            }
        }
    }

    void ReturnPlayer()
    {
        Vector3 spawnPosition = player.transform.position;
        spawnPosition.y = transform.position.y;
        transform.LookAt(player);

        float distance = Vector3.Distance(player.transform.position, this.transform.position);
        if (distance > returnToDistance)
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
            Target = null;
            returnPlayer = true;

        }
        else
        {
            //Made it back to spawn
            GetComponent<Renderer>().material.color = Color.white;
            returnPlayer = false;
        }
    }

    public void FollowPlayer()
    {
        //Same basic tracking script we've been using forever
        if (Vector3.Distance(player.position, this.transform.position) < playerTrackingDistance)
        {
            transform.LookAt(player);
            Vector3 direction = player.transform.position - this.transform.position;
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
        }
        if (Vector3.Distance(player.position, this.transform.position) <= distance)
        {
            this.transform.position = (transform.position - player.transform.position).normalized * distance + player.transform.position;
        }
    }

    void SearchForTarget()
    {
        Vector3 center = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
        Collider[] hitColliders = Physics.OverlapSphere(center, aggroRadius);
        int i = 0;
        while (i < hitColliders.Length)
        {
            if (hitColliders[i].transform.tag == "Chest")
            {
                //can do anything in here like different attacks/abilities, cleave
                Target = hitColliders[i].transform.gameObject;
                GetComponent<Renderer>().material.color = Color.yellow;
                GetComponent<AudioSource>().Play();
            }
            if (hitColliders[i].transform.tag == "enemy")
            {
                isAttack = true;
            }
            //****Here duplicate above and paste above the i++; for it to find other things*****
            i++;
        }
    }

    void FollowTarget()
    {
        //Face towards Target always
        Vector3 targetPosition = Target.transform.position;
        targetPosition.y = transform.position.y;
        transform.LookAt(targetPosition);

        float distance = Vector3.Distance(Target.transform.position, this.transform.position);
        if (distance > 10)
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }
        if (distance <= 10)
        {
            FollowPlayer();
        }
    }
}
